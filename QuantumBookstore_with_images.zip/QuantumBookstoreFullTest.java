public class QuantumBookstoreFullTest {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Book p1 = new PaperBook("P101", "Java Basics", 2015, 200.0, "Alice Smith", 10);
        Book e1 = new EBook("E202", "AI in 2025", 2024, 150.0, "Bob Johnson", "pdf");
        Book s1 = new ShowcaseBook("S303", "Rare Manuscript", 1900, "Dr. Nostalgia");

        inventory.addBook(p1);
        inventory.addBook(e1);
        inventory.addBook(s1);

        System.out.println();

        inventory.buyBook("P101", 2, "buyer@example.com", "123 Elm Street");
        inventory.buyBook("E202", 1, "reader@example.com", "");
        System.out.println();

        try {
            inventory.buyBook("S303", 1, "test@example.com", "123");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        System.out.println();

        inventory.removeOutdatedBooks(10);
    }
}