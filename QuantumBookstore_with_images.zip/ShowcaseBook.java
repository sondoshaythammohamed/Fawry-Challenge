public class ShowcaseBook extends Book {
    public ShowcaseBook(String isbn, String title, int year, String author) {
        super(isbn, title, year, 0.0, author);
    }

    @Override
    public void buy(int quantity, String email, String address) {
        throw new UnsupportedOperationException("Quantum book store: This book is not for sale.");
    }
}