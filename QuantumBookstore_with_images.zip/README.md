# Quantum Bookstore 🛒📚

This is a simple Java-based online bookstore system built for the **Quantum Internship Challenge**.

## 📌 Features

- Supports multiple book types:
  - **PaperBook**: Has stock, ships to address.
  - **EBook**: Has file type, sent via email.
  - **ShowcaseBook**: Not for sale.
- Easily extensible by adding new book types via inheritance.
- Basic purchase functionality using ISBN and quantity.
- Remove outdated books based on publish year.
- All messages are prefixed with `Quantum book store`.

## 🚀 How it looks

### Adding and buying books
![Successful run](images/run-success.png)

### Attempting to buy a ShowcaseBook
![Showcase error](images/showcase-error.png)

### Removing outdated books
![Outdated removal](images/outdated-removal.png)

## 🚀 How to Run

1. Clone the repo or unzip the folder.
2. Compile all `.java` files:
   ```bash
   javac *.java
   ```
3. Run the test class:
   ```bash
   java QuantumBookstoreFullTest
   ```

## ✅ Example Output

```
Quantum book store: Added book: Java Basics
Quantum book store: Added book: AI in 2025
Quantum book store: Added book: Rare Manuscript

Quantum book store: Bought 2x Paper Book 'Java Basics' for 400.0
Quantum book store: Shipping to address: 123 Elm Street
Quantum book store: Bought 1x EBook 'AI in 2025' for 150.0
Quantum book store: Sending to email: reader@example.com
Quantum book store: This book is not for sale.

Quantum book store: Removing outdated book: Rare Manuscript
```

## 🛠 Extensibility

To add a new type of product (like `AudioBook`), simply extend the `Book` class and implement the `buy()` method.

---

© Quantum Internship 2025